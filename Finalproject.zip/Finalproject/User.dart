class User {
  int? id;
  String? firstname;
  String? lastName;
  String? username;
  String? password;
  String? email;
  int? numberPhone;

  User({
    this.id,
    this.firstname,
    this.lastName,
    this.username,
    this.password,
    this.email,
    this.numberPhone,
  });
}
